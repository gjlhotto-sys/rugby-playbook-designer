"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import { RugbyField } from "./rugby-field"
import { PlaybookSidebar } from "./playbook-sidebar"
import { Move, Pencil, Undo2, ChevronDown } from "lucide-react"
import type { FieldPlayer, Arrow, InteractionMode, TeamColors, UndoAction, SavedPlay, PlayType, ArrowType, BallToken, PhaseMarker } from "@/lib/types"
import { RUGBY_POSITIONS, ARROW_TYPES } from "@/lib/types"

const STORAGE_KEY = "rugby-playbook"

export function PlaybookDesigner() {
  const [fieldPlayers, setFieldPlayers] = useState<FieldPlayer[]>([])
  const [arrows, setArrows] = useState<Arrow[]>([])
  const [ball, setBall] = useState<BallToken | null>(null)
  const [phases, setPhases] = useState<PhaseMarker[]>([])
  const [selectedPlayerId, setSelectedPlayerId] = useState<string | null>(null)
  const [selectedBall, setSelectedBall] = useState(false)
  const [mode, setMode] = useState<InteractionMode>("move")
  const [arrowType, setArrowType] = useState<ArrowType>("run")
  const [playName, setPlayName] = useState("")
  const [playType, setPlayType] = useState<PlayType>("Free Play")
  const [notes, setNotes] = useState("")
  const [teamColors, setTeamColors] = useState<TeamColors>({
    attack: "#3B82F6",
    defense: "#EF4444",
  })
  const [undoStack, setUndoStack] = useState<UndoAction[]>([])
  const [savedPlays, setSavedPlays] = useState<SavedPlay[]>([])
  const [arrowDropdownOpen, setArrowDropdownOpen] = useState(false)
  
  // Track drag start state for undo
  const dragStartRef = useRef<{ type: "player" | "ball" | "phase"; id: string; x: number; y: number; arrows: Arrow[] } | null>(null)

  // Load saved plays from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) {
        const parsed = JSON.parse(stored)
        if (Array.isArray(parsed)) {
          setSavedPlays(parsed)
        }
      }
    } catch (e) {
      console.error("Failed to load saved plays:", e)
    }
  }, [])

  // Save plays to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(savedPlays))
    } catch (e) {
      console.error("Failed to save plays:", e)
    }
  }, [savedPlays])

  // Keyboard shortcut for undo
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "z") {
        e.preventDefault()
        handleUndo()
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [undoStack])

  // Close arrow dropdown on outside click
  useEffect(() => {
    const handleClickOutside = () => setArrowDropdownOpen(false)
    if (arrowDropdownOpen) {
      document.addEventListener("click", handleClickOutside)
      return () => document.removeEventListener("click", handleClickOutside)
    }
  }, [arrowDropdownOpen])

  const handleUndo = useCallback(() => {
    if (undoStack.length === 0) return

    const lastAction = undoStack[undoStack.length - 1]
    setUndoStack(prev => prev.slice(0, -1))

    switch (lastAction.type) {
      case "add_player":
        setFieldPlayers(prev => prev.filter(p => p.id !== lastAction.player.id))
        setArrows(prev => prev.filter(a => a.playerId !== lastAction.player.id))
        break
      case "add_arrow":
        setArrows(prev => prev.filter(a => a.id !== lastAction.arrow.id))
        break
      case "move_player":
        setFieldPlayers(prev =>
          prev.map(p =>
            p.id === lastAction.playerId
              ? { ...p, x: lastAction.prevX, y: lastAction.prevY }
              : p
          )
        )
        setArrows(prev => {
          const otherArrows = prev.filter(a => a.playerId !== lastAction.playerId)
          return [...otherArrows, ...lastAction.prevArrows]
        })
        break
      case "add_ball":
        setBall(null)
        setArrows(prev => prev.filter(a => a.playerId !== "ball"))
        break
      case "move_ball":
        setBall(prev => prev ? { ...prev, x: lastAction.prevX, y: lastAction.prevY } : null)
        setArrows(prev => {
          const otherArrows = prev.filter(a => a.playerId !== "ball")
          return [...otherArrows, ...lastAction.prevArrows]
        })
        break
      case "add_phase":
        setPhases(prev => prev.filter(p => p.id !== lastAction.phase.id))
        break
      case "move_phase":
        setPhases(prev =>
          prev.map(p =>
            p.id === lastAction.phaseId
              ? { ...p, x: lastAction.prevX, y: lastAction.prevY }
              : p
          )
        )
        break
    }
  }, [undoStack])

  const handlePlayerDrop = useCallback((playerId: string, x: number, y: number) => {
    const [team, numberStr] = playerId.split("-")
    const number = parseInt(numberStr, 10)
    const positionData = RUGBY_POSITIONS.find(p => p.number === number)

    const newPlayer: FieldPlayer = {
      id: playerId,
      number,
      position: positionData?.position || "",
      abbr: positionData?.abbr || "",
      team: team as "attack" | "defense",
      x,
      y,
    }

    setFieldPlayers(prev => [...prev, newPlayer])
    setUndoStack(prev => [...prev, { type: "add_player", player: newPlayer }])
    setSelectedPlayerId(null)
    setSelectedBall(false)
  }, [])

  const handleBallDrop = useCallback((x: number, y: number) => {
    if (ball) return // Only one ball allowed
    
    const newBall: BallToken = {
      id: `ball-${Date.now()}`,
      x,
      y,
    }
    setBall(newBall)
    setUndoStack(prev => [...prev, { type: "add_ball", ball: newBall }])
  }, [ball])

  const handlePhaseDrop = useCallback((phase: number, x: number, y: number) => {
    const newPhase: PhaseMarker = {
      id: `phase-${phase}-${Date.now()}`,
      phase,
      x,
      y,
    }
    setPhases(prev => [...prev, newPhase])
    setUndoStack(prev => [...prev, { type: "add_phase", phase: newPhase }])
  }, [])

  const handlePlayerDragStart = useCallback((playerId: string) => {
    const player = fieldPlayers.find(p => p.id === playerId)
    if (player) {
      const playerArrows = arrows.filter(a => a.playerId === playerId)
      dragStartRef.current = {
        type: "player",
        id: playerId,
        x: player.x,
        y: player.y,
        arrows: playerArrows,
      }
    }
  }, [fieldPlayers, arrows])

  const handlePlayerDrag = useCallback((playerId: string, x: number, y: number) => {
    setFieldPlayers(prev =>
      prev.map(p =>
        p.id === playerId ? { ...p, x, y } : p
      )
    )
    
    setArrows(prev =>
      prev.map(arrow =>
        arrow.playerId === playerId
          ? { ...arrow, fromX: x, fromY: y }
          : arrow
      )
    )
  }, [])

  const handlePlayerDragEnd = useCallback(() => {
    if (dragStartRef.current && dragStartRef.current.type === "player") {
      const { id: playerId, x: prevX, y: prevY, arrows: prevArrows } = dragStartRef.current
      const player = fieldPlayers.find(p => p.id === playerId)
      
      if (player && (player.x !== prevX || player.y !== prevY)) {
        setUndoStack(prev => [...prev, { 
          type: "move_player", 
          playerId, 
          prevX, 
          prevY,
          prevArrows
        }])
      }
      dragStartRef.current = null
    }
  }, [fieldPlayers])

  const handleBallDragStart = useCallback(() => {
    if (ball) {
      const ballArrows = arrows.filter(a => a.playerId === "ball")
      dragStartRef.current = {
        type: "ball",
        id: "ball",
        x: ball.x,
        y: ball.y,
        arrows: ballArrows,
      }
    }
  }, [ball, arrows])

  const handleBallDrag = useCallback((x: number, y: number) => {
    setBall(prev => prev ? { ...prev, x, y } : null)
    setArrows(prev =>
      prev.map(arrow =>
        arrow.playerId === "ball"
          ? { ...arrow, fromX: x, fromY: y }
          : arrow
      )
    )
  }, [])

  const handleBallDragEnd = useCallback(() => {
    if (dragStartRef.current && dragStartRef.current.type === "ball") {
      const { x: prevX, y: prevY, arrows: prevArrows } = dragStartRef.current
      
      if (ball && (ball.x !== prevX || ball.y !== prevY)) {
        setUndoStack(prev => [...prev, { 
          type: "move_ball",
          prevX, 
          prevY,
          prevArrows
        }])
      }
      dragStartRef.current = null
    }
  }, [ball])

  const handlePhaseDragStart = useCallback((phaseId: string) => {
    const phase = phases.find(p => p.id === phaseId)
    if (phase) {
      dragStartRef.current = {
        type: "phase",
        id: phaseId,
        x: phase.x,
        y: phase.y,
        arrows: [],
      }
    }
  }, [phases])

  const handlePhaseDrag = useCallback((phaseId: string, x: number, y: number) => {
    setPhases(prev =>
      prev.map(p =>
        p.id === phaseId ? { ...p, x, y } : p
      )
    )
  }, [])

  const handlePhaseDragEnd = useCallback(() => {
    if (dragStartRef.current && dragStartRef.current.type === "phase") {
      const { id: phaseId, x: prevX, y: prevY } = dragStartRef.current
      const phase = phases.find(p => p.id === phaseId)
      
      if (phase && (phase.x !== prevX || phase.y !== prevY)) {
        setUndoStack(prev => [...prev, { 
          type: "move_phase", 
          phaseId, 
          prevX, 
          prevY
        }])
      }
      dragStartRef.current = null
    }
  }, [phases])

  const handlePlayerSelect = useCallback((playerId: string | null) => {
    setSelectedPlayerId(playerId)
    if (playerId) setSelectedBall(false)
  }, [])

  const handleBallSelect = useCallback((selected: boolean) => {
    setSelectedBall(selected)
    if (selected) setSelectedPlayerId(null)
  }, [])

  const handleFieldClick = useCallback((x: number, y: number) => {
    if (mode !== "draw") return
    
    if (selectedPlayerId) {
      const player = fieldPlayers.find(p => p.id === selectedPlayerId)
      if (!player) return

      const newArrow: Arrow = {
        id: `arrow-${Date.now()}`,
        playerId: selectedPlayerId,
        team: player.team,
        fromX: player.x,
        fromY: player.y,
        toX: x,
        toY: y,
        arrowType,
      }

      setArrows(prev => [...prev, newArrow])
      setUndoStack(prev => [...prev, { type: "add_arrow", arrow: newArrow }])
      setSelectedPlayerId(null)
    } else if (selectedBall && ball) {
      const newArrow: Arrow = {
        id: `arrow-${Date.now()}`,
        playerId: "ball",
        team: "ball",
        fromX: ball.x,
        fromY: ball.y,
        toX: x,
        toY: y,
        arrowType: "pass", // Ball always uses pass arrow
      }

      setArrows(prev => [...prev, newArrow])
      setUndoStack(prev => [...prev, { type: "add_arrow", arrow: newArrow }])
      setSelectedBall(false)
    }
  }, [mode, selectedPlayerId, selectedBall, fieldPlayers, ball, arrowType])

  const handleDeletePlayer = useCallback((playerId: string) => {
    setFieldPlayers(prev => prev.filter(p => p.id !== playerId))
    setArrows(prev => prev.filter(a => a.playerId !== playerId))
    if (selectedPlayerId === playerId) {
      setSelectedPlayerId(null)
    }
  }, [selectedPlayerId])

  const handleDeleteBall = useCallback(() => {
    setBall(null)
    setArrows(prev => prev.filter(a => a.playerId !== "ball"))
    setSelectedBall(false)
  }, [])

  const handleDeletePhase = useCallback((phaseId: string) => {
    setPhases(prev => prev.filter(p => p.id !== phaseId))
  }, [])

  const handleClearPlayerArrows = useCallback((playerId: string) => {
    setArrows(prev => prev.filter(a => a.playerId !== playerId))
  }, [])

  const handleClearBallArrows = useCallback(() => {
    setArrows(prev => prev.filter(a => a.playerId !== "ball"))
  }, [])

  const handleClearField = useCallback(() => {
    setFieldPlayers([])
    setArrows([])
    setBall(null)
    setPhases([])
    setSelectedPlayerId(null)
    setSelectedBall(false)
    setUndoStack([])
  }, [])

  const handleSavePlay = useCallback(() => {
    const newPlay: SavedPlay = {
      id: `play-${Date.now()}`,
      name: playName || "Untitled Play",
      playType,
      notes,
      timestamp: new Date().toISOString(),
      teamColors,
      players: fieldPlayers,
      arrows: arrows,
      ball,
      phases,
    }
    
    setSavedPlays(prev => [...prev, newPlay])
    console.log("Saved play:", newPlay)
  }, [playName, playType, notes, teamColors, fieldPlayers, arrows, ball, phases])

  const handleLoadPlay = useCallback((play: SavedPlay) => {
    setPlayName(play.name)
    setPlayType(play.playType)
    setNotes(play.notes || "")
    setTeamColors(play.teamColors)
    setFieldPlayers(play.players)
    setArrows(play.arrows)
    setBall(play.ball || null)
    setPhases(play.phases || [])
    setUndoStack([])
    setSelectedPlayerId(null)
    setSelectedBall(false)
  }, [])

  const handleDeletePlay = useCallback((playId: string) => {
    setSavedPlays(prev => prev.filter(p => p.id !== playId))
  }, [])

  const handleDuplicatePlay = useCallback((play: SavedPlay) => {
    const duplicatedPlay: SavedPlay = {
      ...play,
      id: `play-${Date.now()}`,
      name: `${play.name} (Copy)`,
      timestamp: new Date().toISOString(),
    }
    setSavedPlays(prev => [...prev, duplicatedPlay])
  }, [])

  const handleModeChange = useCallback((newMode: InteractionMode) => {
    setMode(newMode)
    setSelectedPlayerId(null)
    setSelectedBall(false)
  }, [])

  const handleTeamColorChange = useCallback((team: "attack" | "defense", color: string) => {
    setTeamColors(prev => ({ ...prev, [team]: color }))
  }, [])

  const selectedArrowType = ARROW_TYPES.find(a => a.type === arrowType)

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-background">
      {/* Main field area with toolbar */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Toolbar */}
        <div className="h-10 bg-sidebar border-b border-sidebar-border flex items-center px-3 gap-2 shrink-0">
          <span className="text-[10px] text-muted-foreground mr-1">Mode:</span>
          <div className="flex rounded-md overflow-hidden border border-border">
            <button
              onClick={() => handleModeChange("move")}
              className={`flex items-center gap-1 px-2 py-1 text-[10px] font-medium transition-colors ${
                mode === "move"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/50 text-muted-foreground hover:bg-muted"
              }`}
            >
              <Move className="w-3 h-3" />
              Move
            </button>
            <button
              onClick={() => handleModeChange("draw")}
              className={`flex items-center gap-1 px-2 py-1 text-[10px] font-medium transition-colors ${
                mode === "draw"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/50 text-muted-foreground hover:bg-muted"
              }`}
            >
              <Pencil className="w-3 h-3" />
              Draw
            </button>
          </div>

          {/* Arrow Type Selector - only visible in draw mode */}
          {mode === "draw" && (
            <div className="relative">
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setArrowDropdownOpen(!arrowDropdownOpen)
                }}
                className="flex items-center gap-1 px-2 py-1 text-[10px] font-medium rounded-md border border-border bg-muted/50 text-foreground hover:bg-muted transition-colors"
              >
                <span className="w-3 h-3 flex items-center justify-center text-[8px]">
                  {arrowType === "pass" ? "🟡" : "→"}
                </span>
                {selectedArrowType?.label}
                <ChevronDown className="w-3 h-3" />
              </button>
              
              {arrowDropdownOpen && (
                <div 
                  className="absolute top-full left-0 mt-1 bg-card border border-border rounded-md shadow-lg py-1 z-50 min-w-[140px]"
                  onClick={(e) => e.stopPropagation()}
                >
                  {ARROW_TYPES.map(at => (
                    <button
                      key={at.type}
                      onClick={() => {
                        setArrowType(at.type)
                        setArrowDropdownOpen(false)
                      }}
                      className={`w-full px-3 py-1.5 text-left text-[10px] hover:bg-muted transition-colors flex items-center gap-2 ${
                        arrowType === at.type ? "bg-muted font-medium" : ""
                      }`}
                    >
                      <span className="w-4 text-center">
                        {at.type === "pass" ? "🟡" : 
                         at.type === "decoy" ? "⋯→" :
                         at.type === "curve" ? "↪" :
                         at.type === "z-left" ? "↙" :
                         at.type === "z-right" ? "↘" :
                         at.type === "loop" ? "↺" :
                         at.type === "short" ? "—" :
                         "→"}
                      </span>
                      <span>{at.label}</span>
                      <span className="text-[8px] text-muted-foreground ml-auto">{at.description}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
          
          <button
            onClick={handleUndo}
            disabled={undoStack.length === 0}
            className="flex items-center gap-1 px-2 py-1 text-[10px] font-medium rounded-md border border-border bg-muted/50 text-muted-foreground hover:bg-muted transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            title="Undo (Ctrl+Z)"
          >
            <Undo2 className="w-3 h-3" />
            Undo
          </button>

          {playName && (
            <span className="ml-auto text-[10px] text-muted-foreground truncate max-w-[200px]">
              {playName}
            </span>
          )}
        </div>

        {/* Field container - fills remaining space */}
        <div className="flex-1 p-2 min-h-0">
          <RugbyField
            players={fieldPlayers}
            arrows={arrows}
            ball={ball}
            phases={phases}
            selectedPlayerId={selectedPlayerId}
            selectedBall={selectedBall}
            mode={mode}
            arrowType={arrowType}
            teamColors={teamColors}
            onFieldClick={handleFieldClick}
            onPlayerDrop={handlePlayerDrop}
            onBallDrop={handleBallDrop}
            onPhaseDrop={handlePhaseDrop}
            onPlayerSelect={handlePlayerSelect}
            onBallSelect={handleBallSelect}
            onPlayerDragStart={handlePlayerDragStart}
            onPlayerDrag={handlePlayerDrag}
            onPlayerDragEnd={handlePlayerDragEnd}
            onBallDragStart={handleBallDragStart}
            onBallDrag={handleBallDrag}
            onBallDragEnd={handleBallDragEnd}
            onPhaseDragStart={handlePhaseDragStart}
            onPhaseDrag={handlePhaseDrag}
            onPhaseDragEnd={handlePhaseDragEnd}
            onDeletePlayer={handleDeletePlayer}
            onDeleteBall={handleDeleteBall}
            onDeletePhase={handleDeletePhase}
            onClearPlayerArrows={handleClearPlayerArrows}
            onClearBallArrows={handleClearBallArrows}
          />
        </div>
      </main>

      {/* Sidebar */}
      <PlaybookSidebar
        playName={playName}
        playType={playType}
        notes={notes}
        onPlayNameChange={setPlayName}
        onPlayTypeChange={setPlayType}
        onNotesChange={setNotes}
        attackPlayers={RUGBY_POSITIONS}
        defensePlayers={RUGBY_POSITIONS}
        fieldPlayers={fieldPlayers}
        ball={ball}
        teamColors={teamColors}
        savedPlays={savedPlays}
        onTeamColorChange={handleTeamColorChange}
        onClearField={handleClearField}
        onSavePlay={handleSavePlay}
        onLoadPlay={handleLoadPlay}
        onDeletePlay={handleDeletePlay}
        onDuplicatePlay={handleDuplicatePlay}
      />
    </div>
  )
}
